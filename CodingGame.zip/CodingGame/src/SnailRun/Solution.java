package SnailRun;

import java.util.*;
import java.io.*;
import java.math.*;
import java.util.HashMap;

/**
 * Auto-generated code below aims at helping you parse the standard input
 * according to the problem statement.
 **/
class Solution
{
    public static void main(String args[])
    {

//        Scanner in = new Scanner(System.in);
//        int numberSnails = in.nextInt();
//        for (int i = 0; i < numberSnails; i++) {
//            int speedSnail = in.nextInt();
//        }
//        int mapHeight = in.nextInt();
//        int mapWidth = in.nextInt();
//        if (in.hasNextLine()) {
//            in.nextLine();
//        }
//        for (int i = 0; i < mapHeight; i++) {
//            String ROW = in.nextLine();
//        }
//      

        String pfad = "C:\\Users\\tngtn\\Downloads\\_akt\\_Dev\\eclipse-workspace\\CodingGame\\src\\SnailRun\\input.txt";
        TextEinlesen te = new TextEinlesen();
        ArrayList<String> in = new ArrayList<String>();
        in = te.textEinlesen(pfad);

        int numberSnails = Integer.parseInt(in.get(0));
        int[] speedOfSnails = new int[numberSnails];

        for (int i = 0; i < numberSnails; i++)
        {
            int speedSnail = Integer.parseInt(in.get(i + 1));
            speedOfSnails[i] = speedSnail;
        }
        int mapHeight = Integer.parseInt(in.get(numberSnails + 1));
        int mapWidth = Integer.parseInt(in.get(numberSnails + 2));
        char[][] map = new char[mapHeight][mapWidth];
        String[] startPos = new String[numberSnails];
        String[] endPos = new String[mapHeight];
        for (int i = 0; i < mapHeight; i++)
        {
            String ROW = in.get(numberSnails + 3 + i);
            for (int j = 0; j < mapWidth; j++)
            {
                char row = ROW.charAt(j);
                map[i][j] = row;
                if ((row + "").matches("[0-9]"))
                {
                    startPos[Character.getNumericValue(row) - 1] = i + " " + j;
                }
                if (row == '#')
                {
                    endPos[i] = (i + " " + j);
                }
            }
            System.err.println(Arrays.toString(map[i]));
        }

        int winner = 0;
        double timer = 99.99;

        for (int i = 0; i < startPos.length; i++)
        {
            //assert startPos[i] != null : "startPos[i] == null";

            double speed = speedOfSnails[i];
            for (int j = 0; j < endPos.length; j++)
            {

                //assert endPos[j] != null : "endPos[j] == null";
                try
                {

                    int x = Math.abs(Integer.parseInt(endPos[j].substring(2, 3))
                            - Integer.parseInt(startPos[i].substring(2, 3)));

                    int y = Math.abs(Integer.parseInt(endPos[j].substring(0, 1))
                            - Integer.parseInt(startPos[i].substring(0, 1)));

                    double time = (x + y) / speed;
                    if (time < timer)
                    {
                        winner = i + 1;
                        timer = time;
                    }
                } catch (Exception e)
                {

                }

            }
        }

//        for (int k=0; k<mapHeight; k++)
//        {
//            System.out.println(Arrays.toString(map[k]));
//        }

        // Write an answer using System.out.println()
        // To debug: System.err.println("Debug messages...");

        System.out.println(winner);
    }
}