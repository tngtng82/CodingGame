package Asteriods;

import java.util.*;

/**
 * Auto-generated code below aims at helping you parse the standard input
 * according to the problem statement.
 **/
class Solution {

	public static void main(String args[]) {
		Solution solu = new Solution();
		String pfad = "C:\\Users\\tngtn\\Downloads\\_akt\\_Dev\\eclipse-workspace\\Asteriods\\input.txt";
		TextEinlesen tE = new TextEinlesen();

		// This list has only 2 columns
		ArrayList<ArrayList<String>> in = tE.textEinlesen(pfad);

		ArrayList<String> in1 = in.get(0);
		ArrayList<String> in2 = in.get(1);

		// the size of the sky-field in width and high
		int W = in1.size();
		int H = in1.get(0).length();

		// at time T
		int T1 = 25;
		int T2 = 75;
		int T3 = 100;

		// Scanner in = new Scanner(System.in);
		// int W = in.nextInt();
		// int H = in.nextInt();
		// int T1 = in.nextInt();
		// int T2 = in.nextInt();
		// int T3 = in.nextInt();

		ArrayList<String> StarT1Data = new ArrayList<String>();
		ArrayList<String> StarT2Data = new ArrayList<String>();

		char[][] skyFieldT3 = new char[H][W];
		ArrayList<String> StarT3Data = new ArrayList<String>();
		
		for (int i = 0; i < H; i++) {
			// String firstPictureRow = in1[i];//in.next();
			// String secondPictureRow = in2[i];//in.next();

			String firstPictureRow = in1.get(i);
			String secondPictureRow = in2.get(i);

			for (int j = 0; j < W; j++) {
				char f = firstPictureRow.charAt(j);
				char s = secondPictureRow.charAt(j);

				if (f != '.') {
					String a = f + " " + i + " " + j;
					StarT1Data.add(a);
				}

				if (s != '.') {
					String a = s + " " + i + " " + j;
					StarT2Data.add(a);
				}

				if (f != s) {
					skyFieldT3[i][j] = '.';
				} else {
					skyFieldT3[i][j] = s;
				}
			}

			System.err.println(i + ": " + firstPictureRow + ", " + secondPictureRow);
		}

		// Write an answer using System.out.println()
		// To debug: System.err.println("Debug messages...");
		System.err.println("unsorted List");
		System.err.println(StarT1Data);
		System.err.println(StarT2Data);
		System.err.println();

		// sorted List
		Collections.sort(StarT1Data);
		Collections.sort(StarT2Data);
		StarT2Data = solu.sortedList(StarT1Data, StarT2Data);
		System.err.println("sorted List");
		System.err.println(StarT1Data);
		System.err.println(StarT2Data);

		StarT3Data = solu.calcT3(StarT1Data, StarT2Data, H, T1, T2, T3);
		System.err.println("T3 List");
		System.err.println(StarT3Data);
		
		//schreibe skyField mit den StarT3Data
		skyFieldT3 = solu.schreibeDatenInSkyField(skyFieldT3, StarT3Data);

		for (int i = 0; i < H; i++) {
			String result = Arrays.toString(skyFieldT3[i]);
			result = result.replace("[", "");
			result = result.replace("]", "");
			result = result.replace(",", "");
			result = result.replace(" ", "");

			System.out.println(result);
		}
	}
	
	private char[][] schreibeDatenInSkyField(char [][] skyField, ArrayList<String> data)
	{
	    for (String s : data)
	    {
	        char c = s.split(" ")[0].charAt(0);
	        int t3h = Integer.parseInt(s.split(" ")[1]);
	        int t3w = Integer.parseInt(s.split(" ")[2]);
	        if (t3h < 0 || t3h > skyField.length || t3w < 0 || t3w > skyField[0].length)
	        {
	           
	        }
	        else
	        {
	        skyField[t3h][t3w] = c;
	        }
	        
	    }
	    
	    return skyField;
	}

	
	private ArrayList<String> sortedList(ArrayList<String> list1, ArrayList<String> list2) {
		ArrayList<String> sortedL = new ArrayList<String>();

		for (int i = 0; i < list1.size(); i++) {
			char chT1 = list1.get(i).charAt(0);
			// sortedL.add(i, "");

			for (int j = i; j < list2.size(); j++) {
				char chT2 = list2.get(j).charAt(0);
				if (chT1 == chT2) {
					sortedL.add(i, list2.get(j));
					break;
				}
			}
		}

		return sortedL;
	}

	private ArrayList<String> calcT3(ArrayList<String> t1, ArrayList<String> t2, int altitudes , int time1, int time2, int time3) {
		
		ArrayList <String> t3Data = new ArrayList<String>();
		
		for (int i = 0; i < t1.size(); i++) {
			String t1Data = t1.get(i);
			String t2Data = t2.get(i);

			int t1H = Integer.parseInt(t1Data.split(" ")[1]);
			int t1W = Integer.parseInt(t1Data.split(" ")[2]);

			int t2H = Integer.parseInt(t2Data.split(" ")[1]);
			int t2W = Integer.parseInt(t2Data.split(" ")[2]);

			String t3Char = t2Data.split(" ")[0];
			int t3H = 0;
			int t3W = 0;

			int first = (int)(Math.floor(t2H - t1H) / (time2 - time1)*(time3-time2));
			int sec = (int)(Math.floor(t2W - t1W) / (time2 - time1)*(time3-time2));
			t3H = t2H + first;
			t3W = t2W + sec;
			
			
//			// identify Position H for T3
//			if (t2H == t1H) {
//				t3H = t2H;
//			} else if (t2H > t1H) {
//				t3H = t2H + Math.abs(t2H - t1H);
//			} else {
//				t3H = t2H - Math.abs(t2H - t1H);
//			}
//
//			if (t3H > altitudes) {
//				t3H = t3 - 1;
//			}
//
//			// identify Position W for T3
//			if (t2W == t1W) {
//				t3W = t2W;
//			} else if (t2W > t1W) {
//				t3W = t2W + Math.abs(t2W - t1W);
//			} else {
//				t3W = t2W - Math.abs(t2W - t1W);
//			}
//
//			if (t3W > altitudes) {
//				t3W = t3 - 1;
//			}
			
			t3Data.add(t3Char+" "+t3H+" "+t3W);

//			try {
//				if (c[t3H][t3W] == '.') {
//					c[t3H][t3W] = t3Char;
//				} else if (c[t3H][t3W] > t3Char) {
//					c[t3H][t3W] = t3Char;
//				}
//			} catch (Exception e) {
//
//			}
		}
		return t3Data;
	}
}
