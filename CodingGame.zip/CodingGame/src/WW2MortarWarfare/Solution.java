package WW2MortarWarfare;

import java.util.ArrayList;
import ParkPilot.TextEinlesen;

public class Solution
{
    private static String input;
    double v = 158; // m/s
    double g = 9.8; // m/s^2

    public Solution(String s)
    {
        input = s;// "-+500+--";
    }

    public static void main(String args[])
    {
        Solution solution = new Solution(input);
        String range = solution.Range(input);
        if (range != "OUT OF RANGE")
        {
            String teta = solution.calcDegrees(range);
            String time = solution.calcTime(teta);
        }

    }
    
    public String Range(String N)
    {
//        TextEinlesen te = new TextEinlesen();
//        ArrayList<String> in = te.textEinlesen(pfad);
//
//        // Scanner in = new Scanner(System.in);
//        // String N = in.nextLine();
//        String N = in.get(0);

        assert N != null;
        int maxRange = 1800;
        String range = "";

        for (int i = 0; i < N.length(); i++)
        {
            String p = N.substring(i, i + 1);
            if (p.matches("[0-9]"))
            {
                range = range + p;
            }
            if (i >= 2 && range.equals(""))
            {
                return "OUT OF RANGE";
            }
        }
        if (Integer.parseInt(range) <= maxRange)
        {
            System.err.println(range);
            return range;
        } else
        {
            return "OUT OF RANGE";
        }

    }

    public String calcDegrees(String R)
    {
        assert R != "OUT OF RANGE";

        double tt = (Math.asin((Integer.parseInt(R) * g) / (v * v))) / 2;
        double teta = 90 - Math.toDegrees(tt);
        double time = (2 * v * Math.sin(teta * Math.PI / 180)) / g;

        // Write an answer using System.out.println()
        // To debug: System.err.println("Debug messages...");

        System.out.println(Math.round(teta * 10) / 10.0 + " " + "degrees");
        // System.out.println(Math.round(time * 10) / 10.0 + " " +
        // "seconds");
        return Math.round(teta * 10) / 10.0 + " " + "degrees";
    }

    public String calcTime(String teta)
    {
        double time = (2 * v * Math.sin(Float.parseFloat(teta.split(" ")[0]) * Math.PI / 180)) / g;

        // Write an answer using System.out.println()
        // To debug: System.err.println("Debug messages...");

        System.out.println(Math.round(time * 10) / 10.0 + " " + "seconds");

        return Math.round(time * 10) / 10.0 + " " + "seconds";
    }

}
