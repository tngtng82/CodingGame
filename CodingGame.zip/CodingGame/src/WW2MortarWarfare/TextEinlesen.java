package WW2MortarWarfare;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.stream.Stream;

public class TextEinlesen {

//	public static void main(String args[]) {
//		TextEinlesen t = new TextEinlesen();
//		String pfad = "C:\\Users\\Nguyen-ccon\\Documents\\_bits\\eclipse-workspace\\Asteriods\\input.txt";
//		t.getInput(pfad);
//	}
	private String pfad;
	
	public TextEinlesen(String pf)
	{
		pfad = pf;
	}
	
	public ArrayList<ArrayList<String>> getText()
	{
		ArrayList <String> a = textEinlesen();
		ArrayList<ArrayList <String>> holeList = new ArrayList<ArrayList <String>>(); 
		
		
		for(int i=0; i<a.size(); i++)
		{
			if((i % 3) == 0)
			{
				ArrayList<String> list = new ArrayList<String>();
				for (int j=i; j<i+4; j++ )
				{
					list.add(a.get(j));
				}
				holeList.add(list);
				//i = j;
			}
			
		}	
		return null;
	}

	public ArrayList<String> textEinlesen() {
		String filename = pfad;
		File file = new File(filename);
		
		ArrayList<String> column1 = new ArrayList<>();
		try (Stream<String> stream = Files.lines(file.toPath())) {
			stream.forEach(line -> {

				column1.add(line.split(" ")[0]);
				//column2.add(line.split(" ")[1]);

			});
		} catch (IOException e) {

			e.printStackTrace();
		}
		return column1;
	}

//	public void getInput(String pfad) {
//
//		ArrayList<ArrayList<String>> input = textEinlesen(pfad);
//		ArrayList<String> i1 = input.get(0);
//		ArrayList<String> i2 = input.get(1);
//		for (int i = 0; i < i1.size(); i++) {
//			String s1 = i1.get(i);
//			String s2 = i2.get(i);
//			System.out.println(s1 + " " + s2);
//
//		}
//	}

}
