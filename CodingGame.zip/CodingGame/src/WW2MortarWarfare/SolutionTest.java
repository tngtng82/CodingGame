package WW2MortarWarfare;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Test;

public class SolutionTest
{
    private Solution solution;
    private String input;
    private TextEinlesen text;

    public SolutionTest()
    {
        //input = "-+500+--";
        String pfad = "C:\\Users\\Nguyen-ccon\\Documents\\_bits\\eclipse-workspace\\CodingGame\\src\\WW2MortarWarfare\\input.txt";
        text = new TextEinlesen(pfad);
        
        ArrayList<ArrayList<String>> a = text.getText();
        
        solution = new Solution(input);
    }
    String getRange()
    {
    	
    	return text.textEinlesen().get(1).toString();
    }

    @Test
    public void range()
    {
        assertEquals(getRange(), solution.Range(input));
    }

    @Test
    public void angle()
    {
        String range = solution.Range(input);
        assertEquals("84.3 degrees", solution.calcDegrees(range));
    }

    @Test
    public void time()
    {
        String range = solution.Range(input);
        String angle = solution.calcDegrees(range);
        assertEquals("32.1 seconds", solution.calcTime(angle));
    }
}
