package WW2MortarWarfare;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Test;

public class SolutionTest
{
 
   @Test
    public void Test()
    {
        
        String pfad = "C:\\Users\\tngtn\\Downloads\\_akt\\_Dev\\eclipse-workspace\\CodingGame\\src\\WW2MortarWarfare\\input.txt";
        TextEinlesen text = new TextEinlesen(pfad);
        ArrayList<ArrayList<String>> a = text.getText();
        ArrayList <String> testInput = new ArrayList<String>();
        
        for (int i=0; i<a.size(); i++)
        {
            testInput = a.get(i);
            String input = testInput.get(0); 
            String rangeValue = testInput.get(1);
            Solution solution = new Solution(input);
            String calcRange = solution.Range(input);
            assertEquals(rangeValue, solution.Range(input));
            if (!calcRange.equals("OUT OF RANGE"))
            {
                String angleValue = testInput.get(2);
                String timeValue = testInput.get(3);
                assertEquals(angleValue, solution.calcDegrees(rangeValue));
                assertEquals(timeValue, solution.calcTime(angleValue));
            }
        
        }
    }
}
