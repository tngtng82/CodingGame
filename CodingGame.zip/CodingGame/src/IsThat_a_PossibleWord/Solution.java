package IsThat_a_PossibleWord;

import java.util.*;

import SnailRun.TextEinlesen;

import java.io.*;
import java.math.*;

/**
 * Auto-generated code below aims at helping you parse the standard input
 * according to the problem statement.
 **/
class Solution
{

    public static void main(String args[])
    {
        Solution sol = new Solution();
        String pfad = "C:\\Users\\tngtn\\Downloads\\_akt\\_Dev\\eclipse-workspace"
                + "\\CodingGame\\src\\IsThat_a_PossibleWord\\input.txt";

        // String pfad =
        // "C:\\Users\\Nguyen-ccon\\Documents\\_bits\\eclipse-workspace\\CodingGame\\src\\IsThat_a_PossibleWord\\input.txt";
        TextEinlesen te = new TextEinlesen();
        ArrayList<String> in = new ArrayList<String>();
        in = te.textEinlesen(pfad);

        String input = "["+in.get(0).replaceAll(" ", "")+"]";
        String states = in.get(1).replaceAll(" ", "");
//        String [] statess = new String [states.length()];
//        for (int i=0; i<statess.length; i++)
//        {
//        	
//        }
//        
        int numberOfTransitions = Integer.parseInt(in.get(2));
        String[] trans = new String[numberOfTransitions];
        for (int i = 0; i < numberOfTransitions; i++)
        {
            String transition = in.get(3 + i);
            trans[i] = transition;
        }
        

        int numberOfWords = Integer.parseInt(in.get(numberOfTransitions + 5));
        for (int i = 0; i < numberOfWords; i++)
        {
            char startStates = in.get(numberOfTransitions + 3).charAt(0); // A
            char endStates = in.get(numberOfTransitions + 4).charAt(0); // B
            String word = in.get(numberOfTransitions + 6 + i);
            System.out.println(word);
            boolean result = false;
            char transState = ' ';
            
            for (int j = 0; j < word.length(); j++)
            {
                char event = word.charAt(j);
                if ((event + "").matches(input))
                {
                    System.err.print(startStates + " " + event);
                    String checkState = sol.checkState(trans, startStates,
                            event); // B
                    
                    if (checkState == null)
                    {
                        result = false;
                        break;
                    }
                                        
                    char state = trans[Character
                            .getNumericValue(checkState.charAt(1))].charAt(4);
                    transState = checkState.charAt(0);
                    startStates = transState;
                    if (state == transState)
                    {
                        result = true;
                    }
                    
                    if(word.length() - 1 == j && transState != endStates)
                    {
                        result = false;
                    }  
                    System.err.println(" " + transState + ":" + result);

                }
                     
                else
                {
                    result = false;
                    break;
                }

            }
            System.out.println(result);
        }
    }

    private String checkState(String[] transition, char startState, char event)
    {
        String endState = null;
        for (int i = 0; i < transition.length; i++)
        {
            char transStartState = transition[i].charAt(0);
            char transEvent = transition[i].charAt(2);
            if (transStartState == startState && transEvent == event)
            {
                endState = transition[i].charAt(4) + "" + i;
                break;
            }
        }
        return endState;
    }
}
