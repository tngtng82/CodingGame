package IsThat_a_PossibleWord;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.stream.Stream;

public class TextEinlesen
{

    public ArrayList<String> textEinlesen(String pfad)
    {
        String filename = pfad;
        File file = new File(filename);

        ArrayList<String> input = new ArrayList<>();
        try (Stream<String> stream = Files.lines(file.toPath()))
        {
            stream.forEach(line ->
            {

                input.add(line);// .split(" ")[0]);
                // column2.add(line.split(" ")[1]);

            });
        } catch (IOException e)
        {

            e.printStackTrace();
        }
        return input;
    }

}
