package exercism;

public class SqueakyClean
{
    public static void main (String [] args) 
    {
        clean("my   Id");
    }
    
    
    /*
     * Implement the (static) SqueakyClean.clean() method to replace any spaces with underscores.
     * This also applies to leading and trailing spaces.
     */
    
    static String clean(String identifier) 
    {
        //throw new UnsupportedOperationException("Please implement the (static)                // SqueakyClean.clean() method");
        for (int i=0; i<identifier.length()-1; i++)
        {
            String a = identifier.substring(i);
        }
                
        return identifier;
    }
}
