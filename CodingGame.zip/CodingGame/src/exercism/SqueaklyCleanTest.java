package exercism;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertThat;

import org.junit.Test;


public class SqueaklyCleanTest
{
    
    @Test
    public void string_with_no_letters() {
      //  assertThat(SqueakyClean.clean("\uD83D\uDE00\uD83D\uDE00\uD83D\uDE00")).isEmpty();
        assertEquals("my   Id", SqueakyClean.clean("my"+ "\uD83D\uDE00\uD83D\uDE00\uD83D\uDE00" + "Id"));
    }

}
