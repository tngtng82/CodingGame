package Asteriods;

import java.util.*;

/**
 * Auto-generated code below aims at helping you parse the standard input
 * according to the problem statement.
 **/
class Solution {

	public static void main(String args[]) {
		Solution solu = new Solution();
		String pfad = "C:\\Users\\Nguyen-ccon\\Documents\\_bits\\eclipse-workspace\\Asteriods\\input.txt";
		TextEinlesen tE = new TextEinlesen();

		// This list has only 2 columns
		ArrayList<ArrayList<String>> in = tE.textEinlesen(pfad);

		ArrayList<String> in1 = in.get(0);
		ArrayList<String> in2 = in.get(1);

		// the size of the sky-field in width and high
		int W = in1.size();
		int H = in1.get(0).length();

		// at time T
		int T1 = 25;
		int T2 = 75;
		int T3 = 100;

		// Scanner in = new Scanner(System.in);
		// int W = in.nextInt();
		// int H = in.nextInt();
		// int T1 = in.nextInt();
		// int T2 = in.nextInt();
		// int T3 = in.nextInt();

		ArrayList<String> StarKOT1 = new ArrayList<String>();
		ArrayList<String> StarKOT2 = new ArrayList<String>();
		ArrayList<String> StarKOT3 = new ArrayList<String>();

		for (int i = 0; i < H; i++) {
			String firstPictureRow = in1.get(i);
			String secondPictureRow = in2.get(i);

			// String firstPictureRow = in.next();
			// String secondPictureRow = in.next();

			for (int j = 0; j < W; j++) {
				char f = firstPictureRow.charAt(j);
				char s = secondPictureRow.charAt(j);

				// erfasst die KO von für T1
				if (f != '.') {

					String a = f + " " + i + " " + j;
					StarKOT1.add(a);
				}

				// erfasst die KO für T2
				if (s != '.') {
					String a = s + " " + i + " " + j;
					StarKOT2.add(a);
				}
			}
		}
		// unsorted KO
		for (int i = 0; i < StarKOT1.size(); i++) {
			System.err.println(i + ": " + StarKOT1.get(i).toString() + ", " + StarKOT2.get(i).toString());
		}

		// sorted KO
		StarKOT2 = solu.sortKO(StarKOT1, StarKOT2);
		for (int i = 0; i < StarKOT1.size(); i++) {
			System.err.println(i + ": " + StarKOT1.get(i).toString() + ", " + StarKOT2.get(i).toString());
		}

		// get Data of StarKOT3
		StarKOT3 = solu.getDataStarT3(StarKOT1, StarKOT2, H, W);
		
		for (int i = 0; i < StarKOT1.size(); i++) {
			System.err.println(i + ": " + StarKOT1.get(i).toString() + ", " + StarKOT2.get(i).toString()+ ","+StarKOT3.get(i));
		}

	}

	private ArrayList<String> getDataStarT3(ArrayList<String> kot1, ArrayList<String> kot2, int grenzeH, int grenzeW)
	{
		ArrayList<String> kot3 = new ArrayList<String>() ; 
		
		for (int i=0; i<kot1.size(); i++)
		{
			
			if(kot1.get(i).equals(kot2.get(i)))
			{
				kot3.add(kot2.get(i));
			}
			else
			{
				char charkot1 = kot1.get(i).charAt(0);
				char charkot2 = kot2.get(i).charAt(0);
						
				if (charkot1 < charkot2)
				{
					kot3.add(kot1.get(i));
				}
			
				else if(charkot1 > charkot2)
				{
					kot3.add(kot2.get(i));
				}
			
				else	//case Character equals but KO different 
				{
					// cal H-KO for T3
					int ht1 = Integer.parseInt(kot1.get(i).split(" ")[1]);		
					int ht2 = Integer.parseInt(kot2.get(i).split(" ")[1]);
					int ht3 = 0;
					
					if(ht1 < ht2)
					{
						ht3 = ht2 + Math.abs(ht2-ht1);
					}
					else
					{
						ht3 = ht2 - Math.abs(ht2-ht1);
					}
					if (ht3 > grenzeH-1)
					{
						ht3 = grenzeH-1;
					}
					else if(ht3 < 0)
					{
						ht3 = 0;
					}
					
					// cal W-KO for T3
					int wt1 = Integer.parseInt(kot1.get(i).split(" ")[2]);
					int wt2 = Integer.parseInt(kot2.get(i).split(" ")[2]);
					int wt3 = 0;
					if(ht1 < ht2)
					{
						wt3 = wt2 + Math.abs(wt2-wt1);
					}
					else
					{
						wt3 = wt2 - Math.abs(wt2-wt1);
					}
					if (wt3 > grenzeW-1)
					{
						wt3 = grenzeW-1;
					}
					else if(wt3 < 0)
					{
						wt3 = 0;
					}
					
					String a = kot1.get(i).charAt(0)+" "+ht3+ " "+ wt3;  
					kot3.add(i,a);
				}
			}
		}
		
		return kot3;
	}

	private ArrayList<String> sortKO(ArrayList<String> KOT1, ArrayList<String> KOT2) {
		Collections.sort(KOT1);
		Collections.sort(KOT2);

		ArrayList<String> KOT2sort = new ArrayList<String>();

		for (int i = 0; i < KOT1.size(); i++) {
			char chT1 = KOT1.get(i).charAt(0);
			KOT2sort.add(i, "");

			for (int j = i; j < KOT2.size(); j++) {
				char chT2 = KOT2.get(j).charAt(0);
				if (chT1 == chT2) {
					KOT2sort.add(i, KOT2.get(j));
					break;
				}
			}
		}

		return KOT2sort;
	}

}
