package WW2MortarWarfare;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Test;

public class SolutionTest
{
    //private Solution solution;
    //private String input;
    private TextEinlesen text;

    public SolutionTest()
    {
        String pfad = "C:\\Users\\Nguyen-ccon\\Documents\\_bits\\eclipse-workspace\\CodingGame\\src\\WW2MortarWarfare\\input.txt";
        text = new TextEinlesen(pfad);
        //solution = new Solution(input);
        startTest();
    }
    
    private void startTest()
    {
    	ArrayList<ArrayList<String>> a = text.getText();
    	for (int i=0; i<a.size(); i++)
    	{
    		String in = a.get(i).get(0);
    		String s = a.get(i).get(1); 
    		range(s, in);
    		if (!s.equals("OUT OF RANGE"))
    		{
    			//angle();
    			//time();
    			
    		}
    	}
    }
    

    @Test
    public void range(String range, String in)
    {
        Solution s = new Solution(in);
    	assertEquals(range, s.Range(in));
    }

//    @Test
//    public void angle()
//    {
//        String range = solution.Range(input);
//        assertEquals("84.3 degrees", solution.calcDegrees(range));
//    }
//
//    @Test
//    public void time()
//    {
//        String range = solution.Range(input);
//        String angle = solution.calcDegrees(range);
//        assertEquals("32.1 seconds", solution.calcTime(angle));
//    }
}
