package ParkPilot;

import java.util.*;
import java.io.*;
import java.math.*;

//import general.TextEinlesen;

/**
 * Find empty park lot for current vehicle
 **/
class Solution {

    public static void main(String args[]) {
        
        String pfad = "C:\\Users\\tngtn\\Downloads\\_akt\\_Dev\\eclipse-workspace\\CodingGame\\src\\ParkPilot\\input.txt";
        //String pfad = "C:\\Users\\Nguyen-ccon\\Documents\\_bits\\eclipse-workspace\\CodingGame\\src\\ParkPilot\\input.txt";
    	TextEinlesen te = new TextEinlesen();
        ArrayList<String> in = te.textEinlesen(pfad);
        
//        Scanner in = new Scanner(System.in);
//        int N = in.nextInt(); // Road length;
//        if (in.hasNextLine()) {
//            in.nextLine();
//        }
        Solution sol = new Solution();
        
        int N = Integer.parseInt( in.get(0));
        int fL=0, fR=0, bR=0, bL=0; 
        int fLmax=0, fRmax=0, bRmax=0, bLmax=0;
        int carLength=0;
        
        for (int i = 1; i < N; i++)
        {
            //String sensorData = in.nextLine(); // Datas from four sensor with values 1 or 0 (e.g 1001)
            String sensorData = in.get(i).toString(); 
            
            //frontLeft frei
            if (sol.cnt(sensorData, 0) == 0)
            {
                fL++;
                if (fL > fLmax)
                {
                	fLmax = fL;
                }
            }
            else
            {
                fL = 0;
            }
            //frontRight frei
            if (sol.cnt(sensorData, 1) == 0)
            {
                fR++;
                if (fR > fRmax)
                {
                	fRmax = fR;
                }
            }
            else
            {
                fR = 0;
            }
            //backRight
            if (sol.cnt(sensorData, 2) == 0)
            {
                bR++;
                if (bR > bRmax)
                {
                	bRmax = bR;
                }
            }
            else
            {
                bR = 0;
            }
            //backLeft
            if (sol.cnt(sensorData, 3) == 0)
            {
                bL++;
                if (bL > bLmax)
                {
                	bLmax = bL;
                }
            }
            else
            {
                bL = 0;
            }
            
            //System.err.println(fL + "" + fR + "" + bR + "" + bL);
            
     	}
        
//        System.err.println(fLmax + ""+ fRmax+""+bRmax+""+bLmax);
        
        if(fLmax == bLmax && fRmax == bRmax)
        {
        	if (fLmax < fRmax && bLmax < bRmax)
        	{
        		carLength = fLmax;
        	}
        	else
        	{
        		carLength = fRmax;
        	}
        }
        System.err.println(carLength);
        

        // Write an answer using System.out.println()
        // To debug: System.err.println("Debug messages...");


        // Length of vehicle
//        // Available park space
//        System.out.println("0");
//        for (int i = 0; i < N; i++) {
//
//            // Write an answer using System.out.println()
//            // To debug: System.err.println("Debug messages...");
//
//
//            // Length of vehicle
//            // Available park space
//            System.out.println("0L");
//        }
    }
    
   
    
    private int cnt(String sensorData, int sensorNr)
    {
        if (sensorData.charAt(sensorNr) == '0')
        {
            return 0;
        }
        else 
        {
            return 1;
        }
   }
}