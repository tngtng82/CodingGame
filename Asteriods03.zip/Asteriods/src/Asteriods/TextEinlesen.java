package Asteriods;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.stream.Stream;

public class TextEinlesen {

//	public static void main(String args[]) {
//		TextEinlesen t = new TextEinlesen();
//		String pfad = "C:\\Users\\Nguyen-ccon\\Documents\\_bits\\eclipse-workspace\\Asteriods\\input.txt";
//		t.getInput(pfad);
//	}

	public ArrayList<ArrayList<String>> textEinlesen(String pfad) {
		String filename = pfad;
		File file = new File(filename);
		// Object efectivly;
		ArrayList<String> column1 = new ArrayList<>();
		ArrayList<String> column2 = new ArrayList<>();

		try (Stream<String> stream = Files.lines(file.toPath())) {
			stream.forEach(line -> {

				column1.add(line.split(" ")[0]);
				column2.add(line.split(" ")[1]);

			});
		} catch (IOException e) {

			e.printStackTrace();
		}

		ArrayList<ArrayList<String>> t = new ArrayList<ArrayList<String>>();

		t.add(column1);
		t.add(column2);

		return t;
	}

	public void getInput(String pfad) {

		ArrayList<ArrayList<String>> input = textEinlesen(pfad);
		ArrayList<String> i1 = input.get(0);
		ArrayList<String> i2 = input.get(1);
		for (int i = 0; i < i1.size(); i++) {
			String s1 = i1.get(i);
			String s2 = i2.get(i);
			System.out.println(s1 + " " + s2);

		}
	}

}
